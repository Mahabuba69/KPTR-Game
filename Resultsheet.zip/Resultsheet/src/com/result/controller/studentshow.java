package com.result.controller;

public class studentshow {
private int id;
private String s_roll;
private String s_reg;
private String s_name;

private String s_fname;
private String s_mname;

private String s_email;
private String s_phone;

private String s_semester;
private String s_department;
private String s_session;



public int gets_Id() {
	return id;
}
public void sets_Id(int id) {
	this.id = id;
}

public String gets_Roll() {
	return s_roll;
}
public void sets_Roll(String s_roll) {
	this.s_roll = s_roll;
}

public String gets_Reg() {
	return s_reg;
}
public void sets_Reg(String s_reg) {
	this.s_reg = s_reg;
}

public String gets_Name() {
	return s_name;
}
public void sets_Name(String s_name) {
	this.s_name = s_name;
}

public String gets_Father_name() {
	return s_fname;
}
public void sets_Father_name(String s_fname) {
	this.s_fname = s_fname;
}


public String gets_Mother_name() {
	return s_mname;
}
public void sets_Mother_name(String s_mname) {
	this.s_mname = s_mname;
}


public String gets_Email() {
	return s_email;
}
public void sets_Email(String s_email) {
	this.s_email = s_email;
}


public String gets_Phone() {
	return s_phone;
}
public void sets_Phone(String s_phone) {
	this.s_phone = s_phone;
}


public String gets_Semester() {
	return s_semester;
}
public void sets_Semester(String s_semester) {
	this.s_semester = s_semester;
}

public String gets_Department() {
	return s_department;
}
public void sets_Department(String s_department) {
	this.s_department = s_department;
}


public String gets_Session() {
	return s_session;
}
public void sets_Session(String s_session) {
	this.s_session = s_session;
}

}
